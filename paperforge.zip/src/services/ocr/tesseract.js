// tesseract OCR
