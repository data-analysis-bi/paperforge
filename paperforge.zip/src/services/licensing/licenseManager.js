// license manager
