export default function Compress(){return <div>Compress</div>}
