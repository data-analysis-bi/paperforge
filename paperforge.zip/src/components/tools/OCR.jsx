export default function OCR(){return <div>OCR</div>}
