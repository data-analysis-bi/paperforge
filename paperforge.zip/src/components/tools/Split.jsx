export default function Split(){return <div>Split</div>}
