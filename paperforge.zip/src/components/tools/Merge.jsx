export default function Merge(){return <div>Merge</div>}
