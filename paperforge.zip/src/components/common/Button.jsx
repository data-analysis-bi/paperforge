export default function Button(){return <button>Button</button>}
