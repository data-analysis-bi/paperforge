export default function Modal(){return <div>Modal</div>}
