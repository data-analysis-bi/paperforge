export default function CanvasLayer(){return <div>Canvas</div>}
