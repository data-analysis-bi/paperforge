export default function Thumbnails(){return <div>Thumbnails</div>}
