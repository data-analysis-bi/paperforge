export default function QuickActions(){return <div>QuickActions</div>}
