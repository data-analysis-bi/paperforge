// Secure IPC bridge
